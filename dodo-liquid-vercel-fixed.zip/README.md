# Dodo Payments — Liquid / 01

A tiny interactive visual toy for the Dodo Payments Design Engineer assignment.

## Interaction
- Move pointer — distort the liquid
- Hold pointer — increase the pull / vortex response
- FLOW — adjust response intensity
- RESET — restore the default flow

## Stack
- Next.js
- React
- WebGL2 fragment shader
- Procedural noise / FBM

## Deploy
This project is prepared as a standalone Next.js app for Vercel. Import the repository into Vercel with the project root left at the repository root.

## If I had more time
I would explore multi-touch, audio-reactive deformation, material presets, and exporting a captured state as an image.
