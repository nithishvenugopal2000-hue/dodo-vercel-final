import './globals.css';
import type { Metadata } from 'next';
export const metadata: Metadata={title:'Liquid / 01 — Shape the flow',description:'A tiny interactive liquid shader toy.'};
export default function Layout({children}:{children:React.ReactNode}){return children;}
